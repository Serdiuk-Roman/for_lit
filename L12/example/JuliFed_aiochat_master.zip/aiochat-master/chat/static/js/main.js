(function () {


    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for(var i = 0; i <ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    function setCookie(name, value, options) {
      options = options || {};

      var expires = options.expires;

      if (typeof expires == "number" && expires) {
        var d = new Date();
        d.setTime(d.getTime() + expires * 1000);
        expires = options.expires = d;
      }
      if (expires && expires.toUTCString) {
        options.expires = expires.toUTCString();
      }

      value = encodeURIComponent(value);

      var updatedCookie = name + "=" + value;

      for (var propName in options) {
        updatedCookie += "; " + propName;
        var propValue = options[propName];
        if (propValue !== true) {
          updatedCookie += "=" + propValue;
        }
      }

      document.cookie = updatedCookie;
    }

    function deleteCookie(name) {
        setCookie(name, "", {
            expires: -1
        })
    }

    if (getCookie('token')) {
        document.getElementById("signin").setAttribute('hidden','hidden');
        document.getElementById("register").setAttribute('hidden','hidden');
        console.log(document.getElementById('login'))
        document.getElementById('login').removeAttribute('hidden');
    }else{
        document.getElementById("logout").setAttribute('hidden','hidden');
    }

    var MessageType = {
        JOIN: 0,
        LEAVE: 1,
        PUBLIC: 2,
        PRIVATE: 3,
        AUTH: 4,
        INFO: 5,
        ERROR: 6, 
    };

    var Connection = undefined,
        People = []
        Messages = [];

    function render_users() {
        var element = document.getElementById('users'),
            tags = [];
        for (var i = People.length - 1; i >= 0; i--) {
            tags.push('<li>' + People[i] + '</li>');
        };
        element.innerHTML = tags.join('');
    };

    function render_message(message) {
        var tag = document.createElement('p');
        if (message.type == MessageType.PRIVATE) {
            message = '<i>Private message from <b>@' + message.from + ':</b> ' + message.text + '</i>';
        } else if (message.type == MessageType.PUBLIC) {
            message = '<b>@' + message.from + ':</b> ' + message.text;
        } else if (message.type == MessageType.JOIN) {
            message = message.user + ' joined room';
        } else if (message.type == MessageType.LEAVE) {
            message = message.user + ' leaved room';
        };
        document.getElementById('messages').insertAdjacentHTML('beforeend', '<p>' + message + '</p>');
    };

    function send_message() {
        var text = document.getElementById('message-text').value;
        if (text.startsWith('@')) {
            var username = text.match(/@\w*/g);
            if (username.length != 0) {
                username = username[0].substring(1, username[0].length);
                message = {
                    type: MessageType.PRIVATE,
                    to: username,
                    text: text.substring(username.length + 2, text.length),
                };
                document.getElementById('messages').insertAdjacentHTML('beforeend', '<p><i>Private message to <b>@' + message.to + ':</b> ' + message.text + '</p>');
            };
        } else {
            message = {
                type: MessageType.PUBLIC,
                text: text,
            };
        };
        Connection.send(JSON.stringify(message));
    };

    function join_chat() {
        Connection = new WebSocket('ws://localhost:8080/chat');
        Connection.onopen = function() {
            Connection.send(JSON.stringify({
                type: MessageType.AUTH,
                token:  getCookie('token') ,
            }));
        };
        Connection.onmessage = function(event) {
            message = JSON.parse(event.data);
            if (message.type == MessageType.ERROR) {
                alert(message.message);
                deleteCookie('token');
                window.location = '/';
            } else if (message.type == MessageType.INFO) {
                People = message.users;
                render_users();
            } else {
                render_message(message);
            };
        };

        document.getElementById('login').setAttribute('hidden','hidden');
        document.getElementById('chat').removeAttribute('hidden')

        document.getElementById('send-message').addEventListener('click', function(event) {
            send_message();
        });
    };

    document.getElementById('join-chat').addEventListener('click', function(event) {
        join_chat();
    });
})();
