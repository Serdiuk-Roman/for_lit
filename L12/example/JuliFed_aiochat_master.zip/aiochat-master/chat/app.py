from aiohttp import web
import os
from chat.routes import setup_routes
from chat.settings import config, BASE_DIR
import aioredis
from jinja2 import FileSystemLoader
from aiohttp_jinja2 import setup
from chat.auth import middleware


async def init_db(app):
    conf = app.config['redis']
    connection = await aioredis.create_redis((conf['host'], conf['port']))
    app.redis = connection


async def close_db(app):
    connection = app.redis
    connection.close()
    

async def create_app():
    app = web.Application(middlewares=[
        middleware.token_auth_middleware,
    ])
    app.on_startup.append(init_db)
    app.on_shutdown.append(close_db)
    setup(app, loader=FileSystemLoader('chat/templates'))
    setup_routes(app)
    app.router.add_static(prefix='/static', name='STATIC', path=os.path.join(BASE_DIR, 'static'))
    app.config = config
    app.config['SECRET_KEY']= b'very-very-secret-key'
    return app








