from chat.auth.views import RegisterView, LoginView, LogoutView
from chat.views import IndexView, ChatroomView

routes = [
    ('GET', '/', IndexView, 'index'),
    ('GET', '/chat', ChatroomView, 'chatroom'),
    ('*', '/register', RegisterView, 'register'),
    ('*', '/login', LoginView, 'Login'),
    ('POST', '/logout', LogoutView, 'Logout'),
]


def setup_routes(app):
    for (method, path, handler, name) in routes:
        app.router.add_route(method, path, handler, name=name)
