from hashlib import pbkdf2_hmac
from binascii import hexlify
from functools import wraps


def login_required(handler):
    handler.login_required = True
    return handler


def anonymous_required(handler):
    handler.anonymous_required = True
    return handler

async def is_valid_token(app, token):
    user = await app.redis.get(app.config['TOKEN_KEY'].format(uuid=token))
    if user:
        return user.decode('utf-8')
    return False


async def is_user_exists(app, username):
    exists = await app.redis.get(app.config['USER_KEY'].format(name=username))
    return exists


def create_hash(app, password):
    if not isinstance(password, bytes):
        password = password.encode('utf-8')
    dk = pbkdf2_hmac('sha256', password, app.config['SECRET_KEY'], 100000)
    return hexlify(dk).decode('utf-8')


async def delete_token(app, token):
    token_key = app.config['TOKEN_KEY'].format(uuid=token)
    await app.redis.delete(token_key)


async def create_token(app, username):
    token = create_hash(app, username)
    token_key = app.config['TOKEN_KEY'].format(uuid=token)
    await app.redis.set(token_key, username)
    #await app.redis.expire(token_key)
    return token


async def create_user(app, username, password):
    password = create_hash(app, password)
    await app.redis.set(app.config['USER_KEY'].format(name=username), password)
    token = await create_token(app, username)
    return token


async def authorize(app, username, password):
    true_password_hash = await app.redis.get(app.config['USER_KEY'].format(name=username))
    provided_password_hash = create_hash(app, password).encode('utf-8')
    return true_password_hash == provided_password_hash
