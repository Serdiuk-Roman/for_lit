from aiohttp import web
from aiohttp_jinja2 import template, render_template
import aiohttp_jinja2

from chat.auth.forms import RegisterForm, LoginForm
from chat.auth.helpers import *


@anonymous_required
@template('register.html')
class RegisterView(web.View):
    
    async def get(self):
        form = RegisterForm()
        return {
            'form': form,
        }
    
    async def post(self):
        form = RegisterForm(await self.request.post())
        if form.validate():
            if not (await is_user_exists(self.request.app, form.username.data)):
                token = await create_user(self.request.app, form.username.data, form.password.data)
                response = web.HTTPFound('/login')
                return response
            else:
                form.username.errors.append('User already exists')
        return {
            'form': form,
        }


@anonymous_required
@template('login.html')
class LoginView(web.View):
    
    async def get(self):
        form = LoginForm()
        return {
            'form': form,
        }
    
    async def post(self):
        form = LoginForm(await self.request.post())
        if form.validate():
            if await authorize(self.request.app, form.username.data, form.password.data):
                token = await create_token(self.request.app, form.username.data)
                # return render_template('index.html', self.request, {'token': token, })
                # redirect(self.request, 'index')
                response = web.HTTPFound('/')
                response.set_cookie('token', token)
                return response
            else:
                form.username.errors.append('Invalid username or password')
        return {
            'form': form,
        }


class LogoutView(web.View):
    
    async def post(self):
        response = web.HTTPFound('/')
        response.del_cookie('token')
        return response

