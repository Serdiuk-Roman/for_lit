AIOCHAT
=====================


Installation
---------

    git clone https://github.com/JuliFed/aiochat aiochat
    cd aiochat
    pyhton3 -m venv .env
    . .env/bin/activate
    pip install -r requirements.txt
    python run.py
    
     

    