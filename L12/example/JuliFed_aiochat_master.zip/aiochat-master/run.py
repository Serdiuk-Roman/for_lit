from aiohttp import web
import asyncio
from chat.app import create_app


loop = asyncio.get_event_loop()
app = loop.run_until_complete(create_app())
web.run_app(app, port=8080)
